#!/bin/bash

sudo /etc/init.d/httpd start
